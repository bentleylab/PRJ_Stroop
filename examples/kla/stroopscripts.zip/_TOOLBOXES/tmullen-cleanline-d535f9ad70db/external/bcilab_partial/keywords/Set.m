function res = Set(varargin)
% shortcut form for exp_set()
res = exp_set(varargin{:});