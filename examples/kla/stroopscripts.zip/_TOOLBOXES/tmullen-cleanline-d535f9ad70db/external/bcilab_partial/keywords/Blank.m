function res = Blank(varargin)
% shortcut form for exp_blank()
res = exp_blank(varargin{:});