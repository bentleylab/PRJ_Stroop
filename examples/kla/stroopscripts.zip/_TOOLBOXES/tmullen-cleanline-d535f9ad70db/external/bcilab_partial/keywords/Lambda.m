function res = Lambda(varargin)
% shortcut form for exp_lambda()
res = exp_lambda(varargin{:});