function varargout = questdlg2(varargin)
error('dialogs disabled.');
