function x = is_point(x)
x = is_1d_regression(x) || is_Nd_regression(x);
